package pojo;

import java.util.List;

/**
 * Created by chetan on 28/4/16.
 */
public class LocationMaster {

    private Integer id ;
    private String name ;
    private String type ;
    private Double latitude ;
    private Double longitude ;
    private static final StringBuilder CSV_BUILDER = new StringBuilder();
    private static final String COMMA = ",";

    /**
     * @param id
     * @param name
     * @param type
     * @param latitude
     * @param longitude
     */
    public LocationMaster(Integer id, String name, String type, Double latitude, Double longitude) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * Generates the csv String passed location type
     * @param locationMaster
     * @return StringBuilder
     */
    public static StringBuilder createCsv(LocationMaster locationMaster) {

        return CSV_BUILDER.append(locationMaster.id)
        .append(COMMA)
        .append(locationMaster.name)
        .append(COMMA)
        .append(locationMaster.type)
        .append(COMMA)
        .append(locationMaster.latitude)
        .append(COMMA)
        .append(locationMaster.longitude);
    }

    /**
     * Generates the csv String of passed List of locations
     *
     * @param locationMasterList
     * @return
     */
    public static String getCsvs(List<LocationMaster> locationMasterList) {
        CSV_BUILDER.delete(0, CSV_BUILDER.length());
        int length = locationMasterList.size();
        for (int i = 0; i < length ; i++) {
            createCsv(locationMasterList.get(i));
            if (i != length - 1) {
                CSV_BUILDER.append(COMMA);
            }
        }
        return CSV_BUILDER.toString();
    }


    /**
     * @return String
     */
    @Override
    public String toString() {
        return "LocationMaster{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                '}';
    }
}
