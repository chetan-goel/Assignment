package process;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * The aim of this class is to query API for getting the locations using Http Protocol
 *
 * Created by chetan on 29/4/16.
 */
public class RequestAPI {

    private static URL url = null;
    private static final StringBuilder link = new StringBuilder("http://api.goeuro.com/api/v2/position/suggest/en/");
    private static final StringBuilder response = new StringBuilder();


    /**
     * Requests the Http server and returns json array for passed city &
     * returns empty json array if city nit found
     *
     * @param cityName
     * @return String
     * @throws Exception
     */
    public static String getRawResponse(String cityName) throws Exception {
            url = new URL(link + cityName);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            response.delete(0, response.length());
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
    }
}
