package util;

import org.json.JSONArray;
import org.json.JSONObject;
import pojo.LocationMaster;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by chetan on 29/4/16.
 */
public class EuroJsonParser {

    private static final String  ID = "_id";
    private static final String  NAME = "name";
    private static final String  TYPE = "type";
    private static final String  LATITUDE = "latitude";
    private static final String  LONGITUDE = "longitude";
    private static final String  GEO_POSITION = "geo_position";
    private static final List<LocationMaster> LOCATION_MASTERS = new ArrayList<>();


    /**
     * Parse the json string and map to objects
     * @param data
     * @return List<LocationMaster>
     */
    public static List<LocationMaster> parseData(String data) throws Exception{

            LOCATION_MASTERS.clear();
            if (data != null) {
                JSONArray jsonArray = new JSONArray(data);
                Iterator jsonObjectIterator = jsonArray.iterator();
                while (jsonObjectIterator.hasNext()) {
                    JSONObject jsonObject = (JSONObject) jsonObjectIterator.next();
                    mapObjects(jsonObject);
                }
            }
        return LOCATION_MASTERS;
    }

    /**
     * Map the json objects to Location Pojos
     *
     * @param jsonObject
     * @throws Exception
     */
    public static void mapObjects(JSONObject jsonObject) throws Exception {

        Integer id = (Integer) jsonObject.get(ID);
        String name = (String) jsonObject.get(NAME);
        String type = (String) jsonObject.get(TYPE);
        JSONObject geoPosition = (JSONObject) jsonObject.get(GEO_POSITION);
        Double longitude = (Double) geoPosition.get(LONGITUDE);
        Double latitude = (Double) geoPosition.get(LATITUDE);

        if (id != null
                && name != null && !name.isEmpty() && !name.equals(" ")
                && type != null && !type.isEmpty() && !type.equals(" ")
                && longitude != null  && !longitude.equals(" ")
                && latitude != null  && !latitude.equals(" ")) {
            LOCATION_MASTERS.add(new LocationMaster(id, name, type, longitude, latitude));
        }else{
            System.out.println("Information is missing for a location id : " + id);
        }

    }
}
