package util;

import pojo.LocationMaster;

import java.io.*;
import java.util.List;

/**
 * Created by chetan on 29/4/16.
 */
public class CsvFileManager {

    /**
     * This method creates the csv file with name Test.csv containing the response
     * in csv format
     *
     * @param locationMasterList
     */
    public static void createAndSaveFile(List<LocationMaster> locationMasterList) throws Exception{

        String csvString = LocationMaster.getCsvs(locationMasterList);
        System.out.println("CSV String : " + csvString);
            File file = new File("Content.csv");
            if (file.exists()) {
                file.delete();
                file.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(csvString);
            bufferedWriter.flush();
            bufferedWriter.close();
        System.out.println("The Csv file named : 'Content.csv' has been created successfully");
    }
}
