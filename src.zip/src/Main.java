import pojo.LocationMaster;
import process.RequestAPI;
import util.CsvFileManager;
import util.EuroJsonParser;

import java.util.List;

/**
 * Created by chetan on 28/4/16.
 */
public class Main {

    public static void main(String[] args) {

        try {
            if (args.length >= 1) {
                String jsonResponse = RequestAPI.getRawResponse(args[0]);
                List<LocationMaster> locationMasterList = EuroJsonParser.parseData(jsonResponse);
                if (locationMasterList.size() == 0) {
                    System.out.println("No Data found in response");
                } else {
                    CsvFileManager.createAndSaveFile(locationMasterList);
                }
            } else {
                System.out.println(" Please enter the city ");
            }
        } catch (Exception e) {
            System.out.println("Failed to complete the request");
            e.printStackTrace();
        }
    }
}